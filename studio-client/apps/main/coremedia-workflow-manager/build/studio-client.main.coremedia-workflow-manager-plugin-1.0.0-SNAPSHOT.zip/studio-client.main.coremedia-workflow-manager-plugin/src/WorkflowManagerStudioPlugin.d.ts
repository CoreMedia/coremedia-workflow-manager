import StudioPlugin from "@coremedia/studio-client.main.editor-components/configuration/StudioPlugin";
import { Config } from "@jangaroo/runtime";
export default class WorkflowManagerStudioPlugin extends StudioPlugin {
    static readonly xtype: string;
    constructor(config?: Config<WorkflowManagerStudioPlugin>);
}
