function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}
const __moduleImports = {
  get StudioPlugin() {
    return _interopRequireDefault(require("@coremedia/studio-client.main.editor-components/configuration/StudioPlugin"))["default"];
  },
  get ConfigUtils() {
    return require("@jangaroo/runtime").ConfigUtils;
  }
};
module.exports = Ext.define("com.coremedia.plugins.workflow.manager.WorkflowManagerStudioPlugin", function (WorkflowManagerStudioPlugin) {
  function WorkflowManagerStudioPlugin$(config = null) {
    this.super$kJrh((() => {
      return __moduleImports.ConfigUtils.apply(config, {});
    })());
  }
  return {
    extend: __moduleImports.StudioPlugin,
    alias: "widget.com.coremedia.plugins.workflow.manager.workflowManagerStudioPlugin",
    constructor: WorkflowManagerStudioPlugin$,
    super$kJrh: function () {
      __moduleImports.StudioPlugin.prototype.constructor.apply(this, arguments);
    }
  };
}, function () {});